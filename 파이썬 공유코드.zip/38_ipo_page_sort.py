import os
import requests
import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
from collections import OrderedDict

def getIPOElements(page_no):
    url = 'https://www.38.co.kr/html/fund/index.htm?o=nw&page={}'.format(page_no)
    # url로부터 신규상장종목 리스트가 들어있는 table 태그를 가져온다. (38커뮤니케이션)
    # summary 속성이 '신규상장종목'인 태그 솔팅

    html = requests.get(url.format(page_no)).text
    soup = BeautifulSoup(html, 'html.parser')
    tables = soup('table')
    table_ipo_list = list(filter(lambda x: x.attrs.get('summary') == '신규상장종목', tables))[0]

    # 테이블 헤더 태그(thead)를 읽는다.
    head = table_ipo_list('thead')[0]
    th = head('tr')[0]('th')
    column_headers = [x.text for x in th]

    # 테이블 본체 (tbody)를 읽어서 리스트에 딕셔너리 형태로 저장
    result = []
    tbody = table_ipo_list('tbody')[0]
    rows = tbody('tr')
    for row in rows:
        td = row('td')
        info = OrderedDict()
        for i, e in enumerate(td):
            header_text = column_headers[i]

            if len(header_text) == 0:
                continue
            temp = e.text.replace('\xa0', '')
            temp = temp.replace('%', '')

            if header_text in ['공모가(원)', '시초가(원)', '첫날종가(원)', '현재가(원)']:
                if temp in ['-', '예정', '상장']:
                    info[header_text] = '' # NaN
                else:
                    info[header_text] = int(temp.replace(',', ''))
            elif header_text in ['공모가대비등락률(%)', '시초/공모(%)', '전일비(%)']:
                if temp in ['-'] or len(temp) == 0:
                    info[header_text] = ''
                else:
                    info[header_text] = float(temp)
            elif header_text in ['신규상장일']:
                info[header_text] = datetime.strptime(e.text, '%Y/%m/%d')
            elif header_text in ['기업명']:
                info[header_text] = temp.replace('(유가)', '')
            else:
                info[header_text] = e.text
        result.append(info)

    return result

# a = getIPOElements(1)
# for i in a:
#     print(i)

# 해당 연도부터 현재까지 상장한 IPO 종목 pandas DF화(스팩, 리츠 제외)
def getIPOAllList(year: int) -> pd.DataFrame:
    result = list()
    page_no = 1 # 1페이지부터 탐색

    while True:
        page_result = getIPOElements(page_no)
        result.extend(page_result)

        dates = [x.get('신규상장일') for x in page_result]
        find = list(filter(lambda x: x.year < year, dates))
        if len(find) > 0:
            break
        page_no += 1
    # 스팩, 리츠 종목은 제외
    result = list(filter(lambda x: x.get('신규상장일').year >= year and '스팩' not in x.get('기업명') and '리츠' not in x.get('기업명'), result))

    return pd.DataFrame(result)

a = getIPOAllList(2022)

print(a['기업명'].head())
print('...')
print(a['기업명'].tail())


# KRX에 상장된 종목(숏코드) data.krx에서 확인
# 다운로드 POST를 특정 주소로 보내주면 데이터를 CSV 형식으로 저장하는 방법, 일회성 토큰방식인지 여부를 모르겠음.
def getKrxStockCsvFile() -> pd.DataFrame:
    target_path = os.path.abspath('./Krx_temp.csv')
    url = 'http://data.krx.co.kr/comm/fileDn/download_csv/download.cmd'
    value = 'yewA9Y8Xg/ZThGWI2oS0KV8Kgcd6eycE9T7vnQnRAcgRtSksuLS7Bnxpl86F7dAOvXfGx9S2U5wgvoxsacATRRtmGtORI4WrGDmruVe6oXtCqUypoW0Lp6SAPP0PhVkgThCTcjIZNPI5lCTubZnhjio6AHXdxc45YVEhz4JdugHPMxvIwHadpQpCGE1HxZAXvTCprTIXuXT9XxFb88awpQ=='

    result = requests.post(url, data={'code': value})
    with open(target_path, 'wb') as fp:
        fp.write(result.content)

    df = pd.read_csv(target_path, encoding = 'cp949')
    os.remove(target_path)

    return df

df = getKrxStockCsvFile()
print(df.columns)
print(df.tail())