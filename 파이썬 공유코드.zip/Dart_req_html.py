# 처음 사용시
# pip install requests (아나콘다에 있음)
# pip install lxml (아나콘다에 있음)
# pip install requests_html

# reference
# https://yogyui.tistory.com/entry/%EA%B8%88%EC%9C%B5%EA%B0%90%EB%8F%85%EC%9B%90DART-%EA%B3%B5%EC%8B%9C%EB%AC%B8%EC%84%9C-js-%EB%A0%8C%EB%8D%94%EB%A7%81%EB%90%9C-HTML-%EA%B0%80%EC%A0%B8%EC%98%A4%EA%B8%B0

import time
from requests_html import HTMLSession

# 코난테크놀로지 투자설명서
rcpNo = '20220624000086'
url_doc = 'https://dart.fss.or.kr/dsaf001/main.do?rcpNo={}'.format(rcpNo)

session = HTMLSession()
response = session.get(url_doc)

# javascript rendering
tm_start = time.perf_counter()
response.html.render()
elapsed = time.perf_counter() - tm_start

session.close()