# 처음 사용시
# pip install requests (아나콘다에 있음)
# pip install dart-fss

# 목표: 증권신고서(지분증권) = 지분증권 OpenAPI 크롤링

# reference1
# 증권신고서 주요정보 - 지분증권 : 개발가이드
# https://opendart.fss.or.kr/guide/detail.do?apiGrpCd=DS006&apiId=2020054
# https://yogyui.tistory.com/entry/MySQL-2021-%EA%B5%AD%EB%82%B4%EC%A3%BC%EC%8B%9D-%EA%B3%B5%EB%AA%A8%EC%A3%BCIPO-%EB%8D%B0%EC%9D%B4%ED%84%B0%EB%B2%A0%EC%9D%B4%EC%8A%A4-%EB%A7%8C%EB%93%A4%EA%B8%B0-3?category=950541

import requests
from io import BytesIO
import zipfile

import xmltodict
import json

api_key = '*********************************'

# 참고: corp_code는 Dart에서 종목별로 부여한 고유번호로, 아래처럼 호출하면 모두 볼 수 있음(ref: http://blog.quantylab.com/2020-10-09-dart.html)
api = 'https://opendart.fss.or.kr/api/corpCode.xml'
res = requests.get(api, params={'crtfc_key': api_key})
z = zipfile.ZipFile(BytesIO(res.content))

data_xml = z.read('CORPCODE.xml').decode('utf-8')
data_odict = xmltodict.parse(data_xml)
data_dict = json.loads(json.dumps(data_odict))
data = data_dict.get('result', {}).get('list')

corp_name = '코난테크놀로지'
for item in data:
    if item['corp_name'] == corp_name:
        corp_code = item['corp_name']
        print(item)

# 코난테크놀로지 투자설명서
# corp_name = '코난테크놀로지'
# corp_code = '00601988'

url = 'https://opendart.fss.or.kr/api/estkRs.json'
params = {
    'crtfc_key': api_key,
    'corp_code': corp_code,
    'bgn_de': '20220101',
    'end_de': '20221231'
}

response = requests.get(url, params=params)
json = response.json()
